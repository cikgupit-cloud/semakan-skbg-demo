# e-Semakan SKBG — Demo Pentadbir

Versi **demo statik** untuk GitHub Pages. Semua markah dan maklumat murid yang dipaparkan adalah rekaan. Fungsi login sebenar, pengesahan penjaga, akses Google Sheets, serta penyimpanan ke pelayan tidak tersedia dalam demo GitHub.

**Dilarang** memuat naik data sebenar murid, nombor MyKid, kod akses, kata laluan atau imej tandatangan rasmi ke repositori awam.

## Terbitkan

1. Buka https://github.com/new dan cipta repository `esemakan-skbg-demo` (Public).
2. Muat naik `index.html` dan `.nojekyll` ke root repository.
3. GitHub Repository **Settings → Pages → Build and deployment → Deploy from a branch → main → /(root) → Save**.
4. Buka alamat GitHub Pages yang diberi dalam Settings → Pages selepas berjaya diterbitkan.

Paparan ini untuk semakan reka bentuk oleh pentadbir, bukan sistem keputusan rasmi sekolah.
